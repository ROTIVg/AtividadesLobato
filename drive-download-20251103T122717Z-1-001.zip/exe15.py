n = int(input())
i = 0
while i * i <= n:
    i += 1
print((i - 1) * (i - 1))
