binario = input()

decimal = 0

for digito in binario:
    decimal = decimal * 2 + int(digito)

print(decimal)
