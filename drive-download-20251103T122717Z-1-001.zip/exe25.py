n = int(input())
for i in range(1,n+1):
    if i%4==0:
        print('pin')
    else:
        print(i)
